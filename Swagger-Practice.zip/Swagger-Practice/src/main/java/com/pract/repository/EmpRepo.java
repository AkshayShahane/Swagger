package com.pract.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.pract.model.Employee;

@Repository
public interface EmpRepo extends CrudRepository<Employee, Integer>{

	Employee findByEmpName(String name);

	Employee readByEmpDesignation(String name);

	Employee getByEmpCity(String name);

	Employee queryBySalary(long name);


}
