package com.pract.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pract.model.Employee;
import com.pract.service.EmpService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping(value = "/emp")
@Api("This is the Employee Controller")
public class EmpController {
	
	@Autowired
	EmpService empService;
	
	@PostMapping("/create")
	@ApiOperation("This is employee creation method")
	public String createEmpRecord(@RequestBody Employee emp) {
		return empService.createEmployeeRecord(emp);
	}
	
	@GetMapping("/getEmp/{id}")
	public Employee getEmployee(
			@ApiParam(value = "id of record that we have to fetch", required = true)
			@PathVariable(name = "id") int id) {
		return empService.getEmployee(id);
	}
	
	@GetMapping("/getAll")
	@ApiResponses(value= {
			@ApiResponse(code = 200,message = "Successfully retrieved"),
			@ApiResponse(code = 401,message = "Unauthorized")})
	public Iterable<Employee> getAllEmployee(){
		return empService.getAllEmployee();
	}

	@PutMapping("/update/{id}")
	public Employee updateEmployee(@RequestBody Employee emp, 
			@PathVariable(value = "id")int id) {
		return empService.updateEmployee(emp, id);
	}
	
	@DeleteMapping("/delete/{id}")
	public String deleteEmployeeRecord(@PathVariable(name = "id")int id) {
		return empService.deleteEmployeeRecord(id);		
	}
	
	@GetMapping("/findByName/{name}")
	public Employee findEmployeeByName(@PathVariable(name = "name")String name) {
		return empService.findEmployeeByName(name);			
	}
	
	@GetMapping("/findByDesignation/{name}")
	public Employee findEmployeeByDesignation(@PathVariable(name = "name")String name) {
		return empService.findEmployeeByDesignation(name);			
	}
	
	@GetMapping("/findByCity/{name}")
	public Employee findEmployeeByCity(@PathVariable(name = "name")String name) {
		return empService.findEmployeeByCity(name);			
	}
	
	@GetMapping("/findBySalary/{salary}")
	public Employee findEmployeeByCity(@PathVariable(name = "salary")long salary) {
		return empService.findEmployeeBySalary(salary);			
	}
}
