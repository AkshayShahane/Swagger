package com.pract.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pract.model.Employee;
import com.pract.repository.EmpRepo;

@Service
public class EmpService {

	@Autowired
	EmpRepo eRepo;
	
	//create
	public String createEmployeeRecord(Employee emp) {
		if(emp!=null) {
			eRepo.save(emp);
			return "Record inserted Successfully...";
		}else {
			return "Record could not inserted..";
		}
	}
	
	//get
	public Employee getEmployee(int id) {
		Employee employee = eRepo.findById(id).orElse(new Employee());
		return employee;
	}
	
	//getAll
	public Iterable<Employee> getAllEmployee(){
	
		return eRepo.findAll();
	}
	
	//update
	public Employee updateEmployee(Employee emp,int id) {
		if(emp!=null) {
			Employee employee = eRepo.findById(id).orElse(new Employee());
			employee.setEmp_city("Pune");
			employee.setEmp_designation("Senior Software Engineer");
			employee.setSalary(50000);
			eRepo.save(employee);
			return employee;
		}else {
			return new Employee();
		}
	}
	
	//delete
	public String deleteEmployeeRecord(int id) {
		if(id!=0) {
			Optional<Employee> employee = eRepo.findById(id);
			eRepo.deleteById(id);
			return "Record Deleted Successfull";
		}else {
			return "Record not deleted because id is 0";
		}
	}
	
	public Employee findEmployeeByName(String name) {
		return eRepo.findByEmpName(name);
	}
	
	public Employee findEmployeeByDesignation(String name) {
		return eRepo.readByEmpDesignation(name);
	}
	
	public Employee findEmployeeByCity(String name) {
		return eRepo.getByEmpCity(name);
	}
	
	public Employee findEmployeeBySalary(long name) {
		return eRepo.queryBySalary(name);
	}
}
