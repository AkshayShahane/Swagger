package com.pract;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pract01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
